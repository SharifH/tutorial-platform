A Pen created at CodePen.io. You can find this one at http://codepen.io/alexiak24/pen/PmmXEO.

 Project for freeCodeCamp course